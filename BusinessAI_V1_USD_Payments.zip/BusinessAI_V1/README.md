# BusinessAI V1 Prototype

This is a front-end prototype of the BusinessAI website.

Included:
- Landing page
- Features and pricing
- Login screen
- Dashboard
- Customers
- Products
- Sales
- Expenses
- Tasks
- Marketing
- Proposals
- AI Assistant
- Reports
- Settings

Important:
This V1 is a visual/interactive prototype. It does not yet have a real database,
real authentication, real AI API, or real payment processing.

Next development stage:
1. Choose production stack
2. Build backend and database
3. Add real authentication
4. Connect AI API
5. Add subscription payments
6. Deploy the website


## USD payments — V1

The prototype now includes:
- USD pricing cards
- Billing page inside the dashboard
- Checkout modal
- Starter $19/month
- Business $49/month
- Professional $99/month
- Production payment architecture notes

The checkout is intentionally a prototype. Do not put secret payment keys in `index.html`.
For production, create a server endpoint that creates the hosted checkout session, then use webhooks to activate/cancel subscriptions.

Important country/eligibility note:
The payment provider must support the legal business entity and payout country. Do not misrepresent the business location or bypass identity/KYC requirements.
